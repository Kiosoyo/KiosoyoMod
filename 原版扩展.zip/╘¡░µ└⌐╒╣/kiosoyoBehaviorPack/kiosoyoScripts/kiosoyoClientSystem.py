# -*- coding: utf-8 -*-

# 获取python27官方模块 time ，用来获取当前的时间，这个模块后续用来指定显示伤害的文字的出现时间
import time
import traceback

# 获取客户端引擎API模块，在客户端对 mc 进行操作需要以此为基础
import mod.client.extraClientApi as clientApi
# 获取客户端system的基类ClientSystem
ClientSystem = clientApi.GetClientSystemCls()

# 在modMain中注册的Client System类。
class KiosoyoClientSystem(ClientSystem):    # ClientSystem 是基类，意思就是 KiosoyoClientSystem 额外具有 ClientSystem 的所有属性。
    en2br = {}  # 这个是用来存储文本面板id和(受伤)实体id的字典，可以通过任意一项取出另一项

    # 客户端System的初始化函数，在 KiosoyoClinetSystem 被创建时会被调用一次
    def __init__(self, namespace, systemName):
        # 首先初始化KiosoyoClientSystem的基类ClientSystem。
        super(KiosoyoClientSystem, self).__init__(namespace, systemName)
        # 调用 ListenEvent 函数
        self.ListenEvent()

    def ListenEvent(self):  # 下面的代码是告诉mc，我要监听 OnScriptTickClient 和 HealthChangeClientEvent 两个事件。这样在这个事件产生时，就会调用相应的函数

        # self.ListenForEvent(
        # clientApi.GetEngineNamespace(),   # 获取 本组件的命名空间
        # clientApi.GetEngineSystemName(),  # 获取 本组件的系统名
        # 'OnScriptTickClient',             # 要监听的事件
        # self,                             # 自身
        # self.OnScriptTickClient           # 回调函数，这个事件发生时被调用一次
        # )

        self.ListenForEvent(clientApi.GetEngineNamespace(), clientApi.GetEngineSystemName(), 'OnScriptTickClient', self, self.OnScriptTickClient)   # 每tick执行一次(1/30秒)
        self.ListenForEvent(clientApi.GetEngineNamespace(), clientApi.GetEngineSystemName(), 'HealthChangeClientEvent', self, self.HealthChangeClientEvent) # 生物血量变化时被执行
        self.ListenForEvent(clientApi.GetEngineNamespace(), clientApi.GetEngineSystemName(), 'ClientItemTryUseEvent', self, self.ClientItemTryUseEvent)

    def HealthChangeClientEvent(self, args):

        # 生成参数，这个相当于蓝图的 取属性值
        a = args['from']
        b = args['to']
        entityId = args['entityId']
        cha = b - a

        # 受到伤害，防止回血时被调用
        if cha < 0 :

            # 保留一位小数或者只留整数。字符串切片： 'str000'[a:b] -> a 开始的位置(计数从零开始)、b 结束的位置(结束的位置的那一个不取，去到前一位)
            _cha = str(cha)                          # 将血量改变量从 float(小数) 转为 str(文本)
            _cha = str(cha)[0:_cha.index('.') + 2]   # 顾头不顾尾，+2就是取到小数点后一位
            if _cha[_cha.index('.') + 1] == '0':     # 如果最后一位是 0 那就去掉小数点和零
                _cha = _cha[0:_cha.index('.')]       # 切片 去掉小数点和零

            # 创建文本面板
            comp = clientApi.GetEngineCompFactory().CreateTextBoard(clientApi.GetLevelId())

            if entityId in self.en2br:  # 因为这个文字面板已经存在，所以直接修改文字就可以
                comp.SetText(self.en2br[str(entityId)]['id'], _cha)     # 修改上面的文字
                self.en2br[str(entityId)]['time'] = time.time()         # 更新保留时间

            else:   # 不存在文本面板，要新建
                boardId = comp.CreateTextBoardInWorld(_cha,(1, 0, 0, 1),(0, 1, 0, 0),True)          # 新建一个文本面板
                if boardId: # 创建成功以后绑定到实体id上
                    comp.SetBoardBindEntity(boardId, entityId, (0.0, 1.0, 0.5), (0.0, 0.0, 0.0))    # 绑定到实体id上
                    self.en2br[str(entityId)] = {'id': boardId, 'time': time.time()}                # 在 en2br字典 中添加一项

    def OnScriptTickClient(self):
        try:    # 防止报错用的，万一出现什么运行错误就不管继续运行
            if len(self.en2br) == 0:
                return

            for i in self.en2br:    # 循环en2br里的每一个key
                if time.time() - self.en2br[i]['time'] > 1: # 保留一秒
                    comp = clientApi.GetEngineCompFactory().CreateTextBoard(clientApi.GetLevelId())
                    comp.RemoveTextBoard(self.en2br[i]['id'])   # 删除文字面板
                    del self.en2br[i]   # 如果不删除会循环报错，因为这个已经不存在了
                else:
                    # 在这个地方让文本向下偏移 (这个太麻烦了不写了)
                    pass
        except Exception as e:
            1+1
            # print(traceback.format_exc())

    def ClientItemTryUseEvent(self, args):
        playerId = args["playerId"]
        ItemName = args['itemDict']['newItemName']

        if ItemName == 'kiosoyo:tnt_throw2':
            # comp = clientApi.GetEngineCompFactory().CreatePos(playerId)
            # entityPos = comp.GetPos()

            comp = clientApi.GetEngineCompFactory().CreateCustomAudio(0)
            musicId = comp.PlayCustomMusic("mob.skeleton.hurt", (0,0,0), 1, 1, False, playerId)
            print(musicId)

    # 函数名为Destroy才会被调用，在这个System被引擎回收的时候会调这个函数来销毁一些内容
    def Destroy(self):
        # ---删除变量---
        del self.en2br
        self.UnListenAllEvents()    # 删除所有事件
        