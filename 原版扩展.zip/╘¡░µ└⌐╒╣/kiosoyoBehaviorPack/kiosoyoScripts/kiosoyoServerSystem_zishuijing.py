# -*- coding: utf-8 -*-

# 获取Python27自带的模块
import time
import traceback

# 获取引擎服务端API的模块
import mod.server.extraServerApi as serverApi
# 获取引擎服务端System的基类，System都要继承于ServerSystem来调用相关函数
ServerSystem = serverApi.GetServerSystemCls()

# 获取组件工厂，用来创建组件
compFactory = serverApi.GetEngineCompFactory()

# 在modMain中注册的Server System类，这个类会被y
class KiosoyoServerSystem(ServerSystem):
    eff2che = {
        # 'playerId': {
        #     'time': 100000    # 药水开始事件，这个效果保留五秒以后刷新
        # }
    }
    diff2che = {
        # 'playerId': {
        #     'time': 100000,    # 效果开始事件，这个效果保留五秒以后刷新
        #     'effect': 'xxx'    # 内部效果名
        # }
    }

    # ServerSystem的初始化函数
    def __init__(self, namespace, systemName):
        # 首先调用父类的初始化函数
        super(KiosoyoServerSystem, self).__init__(namespace, systemName)
        # 初始时调用监听函数监听事件
        self.ListenEvent()

    # 监听函数，用于定义和监听函数。函数名称除了强调的其他都是自取的，这个函数也是。
    def ListenEvent(self):
        self.ListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(), "ServerItemTryUseEvent", self, self.OnServerItemTryUseEvent)
        self.ListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(), "OnScriptTickServer", self, self.OnScriptTickServer)
        self.ListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(), "OnNewArmorExchangeServerEvent", self, self.OnNewArmorExchangeServerEvent)
        # OnNewArmorExchangeServerEvent

    # 监听ServerItemTryUseEvent的回调函数
    def OnServerItemTryUseEvent(self, args):
        def _reducedDurability(_duar):
            # 减少当前手上物品的耐久
            comp = serverApi.GetEngineCompFactory().CreateItem(playerId)
            comp.SetItemDurability(2, 0, duar - _duar)
            # print(duar - _duar)

        playerId = args["playerId"]
        ItemName = args['itemDict']['newItemName']

        # 用于获取手上物品的耐久
        duar_comp = serverApi.GetEngineCompFactory().CreateItem(playerId)
        duar = duar_comp.GetItemDurability(2, 1)

        if ItemName == 'kiosoyo:zishuijing_sword':
            comp = compFactory.CreateEffect(playerId)
            comp.AddEffectToEntity("strength", 3, 3, True)
            _reducedDurability(5)

        if ItemName == 'kiosoyo:zishuijing_pickaxe' or ItemName == 'kiosoyo:zishuijing_axe':
            comp = compFactory.CreateEffect(playerId)
            comp.AddEffectToEntity("haste", 3, 3, True)
            _reducedDurability(5)

    def OnScriptTickServer(self):
        # 用来提供持续药水效果
        now = time.time()
        try:
            for i in self.eff2che:
                cha = now - self.eff2che[i]['time']
                if cha > 2.8:
                    # 添加药水效果
                    comp =compFactory.CreateEffect(i)
                    comp.AddEffectToEntity("speed", 3, 1, True)
                    comp.AddEffectToEntity("jump_boost", 3, 1, True)
                    comp.AddEffectToEntity("resistance", 3, 1, True)
                    comp.AddEffectToEntity("night_vision", 3, 0, True)
                    comp.AddEffectToEntity("health_boost", 3, 1, True)
                    comp.AddEffectToEntity("regeneration", 3, 3, True)
                    comp.AddEffectToEntity("saturation", 3, 1, True)
                    self.eff2che[i]['time'] = now
                    # print('为' + i + '设置药水效果%s'%res)
                    comp = compFactory.CreateItem(i)
                    if not comp.GetEntityItem(serverApi.GetMinecraftEnum().ItemPosType.ARMOR, 1):
                        del self.eff2che[i]
        except Exception as e:
            print(traceback.format_exc())
                # comp.GetEntityItem(serverApi.GetMinecraftEnum().ItemPosType.ARMOR, 1)
                # print(comp.GetEntityItem(serverApi.GetMinecraftEnum().ItemPosType.ARMOR, 1))

    def OnNewArmorExchangeServerEvent(self, args):
        if not args['newArmorDict']:    # 该项为空时，没有新装备替换。
            return
        else:
            newArmor = args['newArmorDict']['newItemName']
            # oldArmor = args['newArmorDict']['oldItemName']
            playerId = args['playerId']
            if newArmor == 'kiosoyo:zishuijing_2':
                # 新建玩家进入字典，生成药水效果交给 OnScriptTickServer
                self.eff2che[playerId] = {'time': time.time()}
            else:
                try:
                    if playerId in self.eff2che:
                        del self.eff2che[playerId]  # 删除他的引索，不再提供药水效果
                except Exception as e:
                    print(traceback.format_exc())

    # 反监听函数，用于反监听事件，在代码中有创建注册就对应了销毁反注册是一个好的编程习惯，不要依赖引擎来做这些事。
    def UnListenEvent(self):
        self.UnListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(), "ServerItemTryUseEvent", self, self.OnServerChat)
        self.UnListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(), "OnScriptTickServer", self, self.OnScriptTickServer)
        self.UnListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(), "OnNewArmorExchangeServerEvent", self, self.OnNewArmorExchangeServerEvent)

    # 函数名为Destroy才会被调用，在这个System被引擎回收的时候会调这个函数来销毁一些内容
    def Destroy(self):
        # 调用上面的反监听函数来销毁
        self.UnListenEvent()
