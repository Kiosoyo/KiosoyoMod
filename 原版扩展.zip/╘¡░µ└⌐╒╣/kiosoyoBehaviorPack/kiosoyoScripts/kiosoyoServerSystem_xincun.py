# -*- coding: utf-8 -*-

# 获取Python27自带的模块
import time
import traceback

# 获取引擎服务端API的模块
import mod.server.extraServerApi as serverApi
# 获取引擎服务端System的基类，System都要继承于ServerSystem来调用相关函数
ServerSystem = serverApi.GetServerSystemCls()

# 获取组件工厂，用来创建组件
compFactory = serverApi.GetEngineCompFactory()

# 在modMain中注册的Server System类，这个类会被y
class KiosoyoServerSystem(ServerSystem):
    eff2che = {
        # 'playerId': {
        #     'time': 100000    # 药水开始事件，这个效果保留五秒以后刷新
        # }
    }

    # ServerSystem的初始化函数
    def __init__(self, namespace, systemName):
        # 首先调用父类的初始化函数
        super(KiosoyoServerSystem, self).__init__(namespace, systemName)
        # 初始时调用监听函数监听事件
        self.ListenEvent()

    # 监听函数，用于定义和监听函数。函数名称除了强调的其他都是自取的，这个函数也是。
    def ListenEvent(self):
        self.ListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(), "ServerItemTryUseEvent", self, self.OnServerItemTryUseEvent)
        self.ListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(), "OnScriptTickServer", self, self.OnScriptTickServer)
        self.ListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(), "OnCarriedNewItemChangedServerEvent", self, self.OnCarriedNewItemChangedServerEvent)
        # OnNewArmorExchangeServerEvent

    # 监听ServerItemTryUseEvent的回调函数
    def OnServerItemTryUseEvent(self, args):
        def _reducedDurability():
            # 减少当前手上物品的耐久
            comp = serverApi.GetEngineCompFactory().CreateItem(playerId)
            comp.SetItemDurability(2, 0, duar - 1)

        playerId = args["playerId"]
        ItemName = args['itemDict']['newItemName']

        # 用于获取手上物品的耐久
        duar_comp = serverApi.GetEngineCompFactory().CreateItem(playerId)
        duar = duar_comp.GetItemDurability(2, 1)

        # 获取维度和坐标
        dim_comp = serverApi.GetEngineCompFactory().CreateDimension(playerId)
        pos_comp = serverApi.GetEngineCompFactory().CreatePos(playerId)

        if ItemName == 'kiosoyo:tnt_throw2':
            comp = compFactory.CreateRot(playerId)
            rot = comp.GetRot() # 获取旋转角度

            x, y, z = serverApi.GetDirFromRot(rot) # 获取朝向
            print(x,y,z)

            motionComp = compFactory.CreateActorMotion(playerId)
            print(motionComp.SetMotion((x*5, y*5, z*5)))
            _reducedDurability()

        if ItemName == 'kiosoyo:tnt_throw':
            comp = compFactory.CreateItem(playerId)
            itemDict = comp.GetPlayerItem(serverApi.GetMinecraftEnum().ItemPosType.CARRIED, 0)
            slot = comp.GetSelectSlotId()
            count = itemDict['count']
            comp.SetInvItemNum(slot, count-1)

            comp = compFactory.CreateProjectile(dim_comp.GetEntityDimensionId())

            # 这里用创建投掷物创建tnt会报错，所以用实体创建。
            entityId = self.CreateEngineEntityByTypeStr('minecraft:tnt', pos_comp.GetPos(), (0, 0), dim_comp.GetEntityDimensionId())

            # 创建用于获取旋转角度的工厂
            comp = compFactory.CreateRot(playerId)
            rot = comp.GetRot() # 获取旋转角度

            x, y, z = serverApi.GetDirFromRot(rot) # 获取朝向

            motionComp = compFactory.CreateActorMotion(entityId)
            motionComp.SetMotion((x * 0.7, y * 0.7, z * 0.7))

    def OnScriptTickServer(self):
        # 用来提供持续药水效果
        now = time.time()
        try:
            for i in self.eff2che:
                cha = now - self.eff2che[i]['time']
                if cha > 2.8:
                    # 添加药水效果
                    comp =compFactory.CreateEffect(i)
                    comp.AddEffectToEntity("haste", 3, 1, True)
                    comp = compFactory.CreateItem(i)
                    try:
                        if comp.GetEntityItem(serverApi.GetMinecraftEnum().ItemPosType.CARRIED, 1):
                            # print(comp.GetEntityItem(serverApi.GetMinecraftEnum().ItemPosType.CARRIED, 1)['newItemName'])
                            if comp.GetEntityItem(serverApi.GetMinecraftEnum().ItemPosType.CARRIED, 1)['newItemName'] != 'kiosoyo:tnt_throw2':
                                del self.eff2che[i]
                        else:
                            del self.eff2che[i]
                    except Exception as e:
                        1+1
        except Exception as e:
            print(traceback.format_exc())

    def OnCarriedNewItemChangedServerEvent(self, args):
        playerId = args['playerId']
        try:
            if args['newItemDict']:
                newItemName = args['newItemDict']['newItemName']
                print(newItemName)
                if newItemName == 'kiosoyo:tnt_throw2':
                    self.eff2che[playerId] = {'time': time.time()}
                else:
                    if playerId in self.eff2che:
                        del self.eff2che[playerId]  # 删除他的引索，不再提供药水效果
            else:
                del self.eff2che[playerId]  # 删除他的引索，不再提供药水效果
        except Exception as e:
            1+1
        
    # 反监听函数，用于反监听事件，在代码中有创建注册就对应了销毁反注册是一个好的编程习惯，不要依赖引擎来做这些事。
    def UnListenEvent(self):
        self.UnListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(), "ServerItemTryUseEvent", self, self.OnServerChat)
        self.UnListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(), "OnScriptTickServer", self, self.OnScriptTickServer)
        self.UnListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(), "OnCarriedNewItemChangedServerEvent", self, self.OnCarriedNewItemChangedServerEvent)

    # 函数名为Destroy才会被调用，在这个System被引擎回收的时候会调这个函数来销毁一些内容
    def Destroy(self):
        # 调用上面的反监听函数来销毁
        self.UnListenEvent()
