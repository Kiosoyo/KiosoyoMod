# -*- coding: utf-8 -*-

from common.mod import Mod
import mod.server.extraServerApi as serverApi


@Mod.Binding(name="Script_KiosoyoMod", version="0.0.1")
class Script_KiosoyoMod(object):

    def __init__(self):
        pass

    @Mod.InitServer()
    def Script_KiosoyoModServerInit(self):
        serverApi.RegisterSystem("KiosoyolMod", "KiosoyoServerSystem", "Script_KiosoyoMod.KiosoyoServerSystem.KiosoyoServerSystem")

    @Mod.DestroyServer()
    def Script_KiosoyoModServerDestroy(self):
        pass

    @Mod.InitClient()
    def Script_KiosoyoModClientInit(self):
        pass

    @Mod.DestroyClient()
    def Script_KiosoyoModClientDestroy(self):
        pass
