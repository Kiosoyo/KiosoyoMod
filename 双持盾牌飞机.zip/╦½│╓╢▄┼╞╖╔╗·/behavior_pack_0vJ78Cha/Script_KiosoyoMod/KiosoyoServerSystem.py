# -*- coding: utf-8 -*-

import time
import mod.server.extraServerApi as serverApi
ServerSystem = serverApi.GetServerSystemCls()
compFactory = serverApi.GetEngineCompFactory()


class KiosoyoServerSystem(ServerSystem):
    pl2di = {}

    def __init__(self, namespace, systemName):
        ServerSystem.__init__(self, namespace, systemName)
        self.listenEvent()

    def listenEvent(self):
        self.ListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(), "OnScriptTickServer", self, self.OnScriptTickServer)
        self.ListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(), "OnCarriedNewItemChangedServerEvent", self, self.OnCarriedNewItemChangedServerEvent)
        self.ListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(), "OnOffhandItemChangedServerEvent", self, self.OnOffhandItemChangedServerEvent)
        self.ListenForEvent(serverApi.GetEngineNamespace(), serverApi.GetEngineSystemName(), "ServerItemTryUseEvent", self, self.ServerItemTryUseEvent)


    def OnScriptTickServer(self):
        for i in self.pl2di:
            di = self.pl2di[i]
            if 'Carried' not in di or 'offHand' not in di:
                return
            if di['Carried'] and di['offHand']:
                if 'fly' not in di:
                    di['fly'] = None
                if di['fly'] == False or di['fly'] == None:
                    di['fly'] = True
                    comp = serverApi.GetEngineCompFactory().CreateFly(i)
                    comp.ChangePlayerFlyState(True)
            else:
                if 'fly' not in di:
                    di['fly'] = None
                comp = serverApi.GetEngineCompFactory().CreateFly(i)
                comp.ChangePlayerFlyState(False)
                di['fly'] = False

        # 用于持续添加飞行向量

    def OnCarriedNewItemChangedServerEvent(self, args):
        if args['newItemDict']:
            if args['newItemDict']['newItemName'] == 'minecraft:shield':
                if args['playerId'] in self.pl2di:
                    self.pl2di[args['playerId']]['Carried'] = True
                else:
                    self.pl2di[args['playerId']] = {'Carried': True}
                return
        if args['playerId'] in self.pl2di:
            self.pl2di[args['playerId']]['Carried'] = False
        # 主手物品切换

    def OnOffhandItemChangedServerEvent(self, args):
        if args['newItemDict']:
            if args['newItemDict']['newItemName'] == 'minecraft:shield':
                if args['playerId'] in self.pl2di:
                    self.pl2di[args['playerId']]['offHand'] = True
                else:
                    self.pl2di[args['playerId']] = {'offHand': True}
                return
        if args['playerId'] in self.pl2di:
            self.pl2di[args['playerId']]['offHand'] = False
        # 副手物品切换

    def ServerItemTryUseEvent(self, args):
        playerId = args["playerId"]
        ItemName = args['itemDict']['newItemName']
        if ItemName == 'minecraft:shield':
            dim_comp = serverApi.GetEngineCompFactory().CreateDimension(playerId)
            comp = compFactory.CreateProjectile(dim_comp.GetEntityDimensionId())
            comp.CreateProjectileEntity(playerId, 'minecraft:arrow', {'power': 15})
            
        # 机炮

    def Destroy(self):
        pass