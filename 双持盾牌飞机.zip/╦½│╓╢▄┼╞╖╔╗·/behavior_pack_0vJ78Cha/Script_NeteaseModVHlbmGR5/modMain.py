# -*- coding: utf-8 -*-

from common.mod import Mod


@Mod.Binding(name="Script_NeteaseModVHlbmGR5", version="0.0.1")
class Script_NeteaseModVHlbmGR5(object):

    def __init__(self):
        pass

    @Mod.InitServer()
    def Script_NeteaseModVHlbmGR5ServerInit(self):
        pass

    @Mod.DestroyServer()
    def Script_NeteaseModVHlbmGR5ServerDestroy(self):
        pass

    @Mod.InitClient()
    def Script_NeteaseModVHlbmGR5ClientInit(self):
        pass

    @Mod.DestroyClient()
    def Script_NeteaseModVHlbmGR5ClientDestroy(self):
        pass
